--- / --- / --- KIEPIC --- / --- / ---

# Kiepic 1.0.1 - Professional Desktop Image Editor

> **Package ID:** `bretoadrian.kiepic.desktop`  
> **Author:** bretoadrian (Bretoox)

---

**Kiepic** is a robust, feature-rich desktop image editing application built entirely in Python using Tkinter and Pillow. Designed to offer a seamless, independent, and fast editing experience on Windows without requiring complex installations.

---

## Key Features

- **Advanced File & History Management:** Full **Undo & Redo** stack so you can experiment freely without losing track of your edits.
- **Light & Dark Theme Toggle:** Switch dynamically between a modern sleek Dark Mode and a crisp Frutiger Aero / Glossy Light Mode.
- **Professional Color & Light Adjustments:** Real-time controls for Brightness, Contrast, Color Saturation, and Advanced Sharpness.
- **Artistic Filters & Styles:** Classic Grayscale, Color Inversion, Vintage Sepia, Soft Blur, Edge Detection, Detail Enhancement, and Solarization.
- **Geometry & Orientation:** Horizontal/Vertical Flips, 90° Rotations, and Quick Resizing.
- **Integrated Text & Watermarking Studio:** Custom text stamping with adjustable font sizes, color palettes, and official developer signatures.
- **Live Dimension Indicator:** Real-time image resolution feedback directly on the interface status bar.

---

## Getting Started & Usage

If you have the source code (`editor.py`) and Python installed, you can run it directly:

1. **Install Prerequisites:**
   ```bash
   pip install Pillow